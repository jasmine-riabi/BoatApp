package com.example.escales

data class Escale(var image: Int, var pays: String, var ville: String, var dateA: String, var dateD: String){
}