package com.example.boatapp.ui.escale

interface CellClickListener {
    fun onCellClickListener(ville: String)
}